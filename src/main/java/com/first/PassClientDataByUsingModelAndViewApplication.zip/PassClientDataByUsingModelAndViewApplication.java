package com.first;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PassClientDataByUsingModelAndViewApplication {

	public static void main(String[] args) 
	{
		SpringApplication.run(PassClientDataByUsingModelAndViewApplication.class, args);
	}

}
