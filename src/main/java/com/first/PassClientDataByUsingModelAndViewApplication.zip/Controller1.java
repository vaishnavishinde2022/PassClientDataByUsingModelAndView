package com.first;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Controller1 
{
	@RequestMapping("/courses")
	
  public ModelAndView courses(@RequestParam("coursename")String courseName)
  {
		ModelAndView mv=new ModelAndView();
		mv.addObject("cname",courseName);
		
		mv.setViewName("courses.jsp");
		
		return mv;
	  
  }
}
